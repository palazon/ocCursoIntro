# OpenCode 101 — Curso básico para creadores de contenido

Curso práctico de **12 pasos** para aprender a usar OpenCode como
asistente de IA en tareas de documentación técnica, redacción de
informes, material educativo e investigación.

## Cómo usar este curso

1. Asegúrate de tener [OpenCode](https://opencode.ai) instalado
2. Abre `index.html` en tu navegador para ver el curso
3. Sigue los pasos secuencialmente

Para más información visita
<https://palazon.github.io/ocCursoIntro/>.

---

*Curso OpenCode 101 · JA Palazón · Mayo 2026*
