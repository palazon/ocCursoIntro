#!/bin/bash
# Render all course files to HTML
quarto render *.qmd
echo "Todos los HTML generados en $(pwd)"
